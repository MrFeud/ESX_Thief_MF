# fxserver-esx_thief
FXServer ESX Thief

Rework from the original esx_thief.

You can steal someone by pointing at them with your gun. The target has to hands up!

Only items, cash and black money can be stolen.


## INSTALLATION

1) CD in your resources/[esx] folder
2) Clone the repository
3) Copy the handsup.lua file wherever you want
4) Add this in your server.cfg :

```
start esx_thief
```
